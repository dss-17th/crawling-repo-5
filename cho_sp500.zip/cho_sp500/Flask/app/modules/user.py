host = '34.134.233.184'
user = 'root'
pw = 'dss'
db = 'US_Stock'

