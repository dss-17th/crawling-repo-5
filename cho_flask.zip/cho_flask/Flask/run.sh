# article.py에 있는 객체
export FLASK_APP=US_Stock.py
# DEBUG=True
export FLASK_DEBUG=1
flask run
