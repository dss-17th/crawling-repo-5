from app import app # app 디렉토리에서 __init__에 있는 app 객체를 import
